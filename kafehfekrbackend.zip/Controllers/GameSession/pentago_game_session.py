import asyncio
import random

from Entities.Games.Pentago import PentagoGameClass
from Entities.Games.game_types import GameTypesEnum
from Entities.Games.wait_times import Pentago_Turn_Time
from Commons.static_functions import make_command_json
from Commons import commands
from Controllers.GameSession import BaseGameSession


class PentagoGameSession(BaseGameSession):
    def __init__(self, game_id: str, game_type, game_score_type):
        super().__init__(game_id, game_type, game_score_type)

    def start_game_timer(self):
        self.game_controller = PentagoGameClass(send_data_function=self.send_command)
        self.game_type = GameTypesEnum.PENTAGO
        super().start_game_timer()

    async def command_received(self, data, socket_id):
        gamer_id = await super().command_received(data, socket_id)
        if gamer_id is None:
            return
        if data['id'] == commands.Select_Peace:
            peace_id = data['data']
            is_selection_authorized = self.game_controller.check_authority(peace_id, gamer_id)
            if is_selection_authorized:
                await self.game_controller.recieve_data(data['id'], peace_id, gamer_id)
        if data['id'] == commands.Rotate_Peace:
            rotate_id = data['data']
            is_rotation_authorized = self.game_controller.check_rotate_authority(rotate_id, gamer_id)
            if is_rotation_authorized:
                await self.game_controller.recieve_data(data['id'], rotate_id, gamer_id)
                self.timer.stop()

    def send_current_turn(self):
        from Entities.SocketIOManagerClass import send_command
        # auto rotate if user not rotated
        if self.game_controller.current_round != 0 and not self.game_controller.rotation_played:
            random_index = random.randint(1, 8)
            self.game_controller.rotate_piece(random_index)
            self.game_controller.rotation_played = True
            asyncio.new_event_loop().run_until_complete(send_command(
                command=make_command_json(id=commands.Peace_Rotated, data={'user': self.game_controller.current_turn,
                                                                           'rotation_id': random_index,
                                                                           'board': self.game_controller.board}),
                game_id=self.game_id))
        if self.game_controller.check_game_ended():
            winner = self.game_controller.get_game_winner()
            asyncio.new_event_loop().run_until_complete(
                send_command(
                    command=make_command_json(id=commands.Finish_Game, data={"Winner": winner}),
                    game_id=self.game_id))
            self.finish_game(winner)
            return
        self.game_controller.change_turn()

        def function():
            asyncio.new_event_loop().run_until_complete(
                send_command(
                    command=make_command_json(id=commands.Current_Turn, data=self.game_controller.current_turn),
                    game_id=self.game_id))
            self.timer.start(Pentago_Turn_Time, self.send_current_turn)

        if self.game_controller.current_round == 1:
            function()
        else:
            self.timer.start(2, function)
